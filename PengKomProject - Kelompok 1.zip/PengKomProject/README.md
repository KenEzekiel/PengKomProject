# PengKomProject
Repository for our group's PengKom projects.

Repository ini akan ditujukan untuk tugas besar pengenalan komputasi kelompok 1

Tema tugas besar: pencarian rute dalam aplikasi google maps

Anggota:
Akmal Mahardika NP / 16521070
Fildza Haniifa B / 16521270
Kenneth Ezekiel S / 16521040
Marvel Subekti / 16521220
Victoria Angelique / 16521460

Topik tugas besar kami adalah tentang Pencarian rute tercepat pada google maps dengan menggunakan algoritma Dijkstra

nama file final : tubes_gmaps_main.py

github repo: https://github.com/KenEzekiel/PengKomProject
